export const  inputArray = [
    "https://www.zara.com/in/en/slim-fit-t-shirt-p00722326.html?v1=409880300&v2=2477369"
];